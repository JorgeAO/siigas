<?php

class YourFirstTest extends \PHPUnit\Framework\TestCase
{
    public function testYourTestMethod()
    {
        $value = true;

        $this->assertTrue($value);
    }
}
